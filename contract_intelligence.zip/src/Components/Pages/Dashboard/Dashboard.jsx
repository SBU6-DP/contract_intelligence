import React from 'react'
import Layouts from '../Layouts/Layouts'

function Dashboard() {
  return (
    <Layouts>
      <div className="container-fluid">
        <div className="container">
          <div className="row">
            <div className="col-6">

            </div>
            <div className="col-6">
              
            </div>
          </div>
        </div>
      </div>
    </Layouts>
  );
}

export default Dashboard