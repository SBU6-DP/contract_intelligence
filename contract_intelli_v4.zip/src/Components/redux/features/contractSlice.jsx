import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  contracts: [],
};

export const contractsSlice = createSlice({
  name: "contracts",
  initialState,
  reducers: {
    saveContracts:(state,action)=>{
        state.contracts =action.payload;
    },
    clearContracts: (state) => {
      state.contracts = [];
    },
  },
});

export const { clearContracts, saveContracts } =
  contractsSlice.actions;

export default contractsSlice.reducer;
