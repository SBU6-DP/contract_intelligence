import {
  BrowserPerformanceMeasurement
} from "./chunk-DZB2FKDO.js";
import "./chunk-DC5AMYBS.js";
export {
  BrowserPerformanceMeasurement
};
